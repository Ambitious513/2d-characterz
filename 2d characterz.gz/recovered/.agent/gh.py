import json,os,sys,urllib.request,urllib.error
TOK=os.environ.get("GH_TOKEN","")
def api(path):
    req=urllib.request.Request("https://api.github.com"+path,headers={
        "Authorization":"Bearer "+TOK,"Accept":"application/vnd.github+json",
        "User-Agent":"agent","X-GitHub-Api-Version":"2022-11-28"})
    try:
        with urllib.request.urlopen(req,timeout=60) as r:
            return r.status, json.load(r)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:2000]
    except Exception as e:
        return -1, str(e)
if __name__=="__main__":
    for p in sys.argv[1:]:
        s,d=api(p)
        print("==",p,s)
        print(json.dumps(d,indent=1)[:8000] if not isinstance(d,str) else d)
