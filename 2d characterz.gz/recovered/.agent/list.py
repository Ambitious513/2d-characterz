import sys; sys.path.insert(0,'.agent')
from gh import api
import json
for path in ["/user/repos?per_page=100&affiliation=owner,collaborator,organization_member&sort=updated","/user/installations"]:
    s,d=api(path)
    print("==",path,s)
    if isinstance(d,list):
        for r in d:
            print(f"{r['full_name']:<50} private={r['private']!s:<5} pushed={r['pushed_at']} lang={r['language']} desc={r.get('description')}")
    else:
        print(json.dumps(d)[:1500])
