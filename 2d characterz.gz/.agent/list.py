import sys; sys.path.insert(0,'.agent')
from gh import api
import json
s,d=api("/user/repos?per_page=100&affiliation=owner,collaborator,organization_member&sort=updated")
print("status",s)
if isinstance(d,list):
    for r in d:
        print(f"{r['full_name']:<45} private={r['private']!s:<5} pushed={r['pushed_at']} lang={r['language']} default={r['default_branch']}")
else: print(json.dumps(d)[:1500])
